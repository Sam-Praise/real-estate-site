async function fetchListings() {
  try {
    const res = await fetch('/api/listings');
    if (!res.ok) throw new Error('Failed to load listings');
    const data = await res.json();
    return data;
  } catch (e) {
    console.error(e);
    return [];
  }
}

function createPropertyCard(listing) {
  const div = document.createElement('div');
  div.className = 'property-card';
  div.innerHTML = `
    <div class="property-image">
      <span>${listing.status || ''}</span>
    </div>
    <div class="property-body">
      <h3 class="property-title">${listing.title}</h3>
      <p class="property-location">${listing.location}</p>
      <div class="property-meta">
        ${listing.beds ? `<span>${listing.beds} Beds</span>` : ''}
        ${listing.baths ? `<span>${listing.baths} Baths</span>` : ''}
        ${listing.size ? `<span>${listing.size}</span>` : ''}
      </div>
    </div>
    <div class="property-footer">
      <span>${listing.price}</span>
      <span>Listed on ${new Date(listing.createdAt || Date.now()).toLocaleDateString()}</span>
    </div>
  `;
  return div;
}

async function renderHomepageListings() {
  const container = document.getElementById('latest-listings');
  if (!container) return;
  const listings = await fetchListings();
  const latest = listings.slice(-3).reverse();
  latest.forEach(listing => {
    container.appendChild(createPropertyCard(listing));
  });
}

async function renderAllListings() {
  const grid = document.getElementById('listings-grid');
  if (!grid) return;
  const listings = await fetchListings();

  const form = document.getElementById('search-form');
  function applyFilters(e) {
    if (e) e.preventDefault();
    const q = (document.getElementById('q').value || '').toLowerCase();
    const status = document.getElementById('status').value;
    const minPrice = parseFloat(document.getElementById('minPrice').value || '0');

    grid.innerHTML = '';
    listings
      .filter(l => {
        const matchesStatus = !status || l.status === status;
        const matchesKeyword =
          !q ||
          l.title.toLowerCase().includes(q) ||
          l.location.toLowerCase().includes(q);
        const priceNumber = parseFloat(String(l.price).replace(/[^0-9.]/g, '')) || 0;
        const matchesPrice = !minPrice || priceNumber >= minPrice;
        return matchesStatus && matchesKeyword && matchesPrice;
      })
      .forEach(l => grid.appendChild(createPropertyCard(l)));
  }

  if (form) {
    form.addEventListener('submit', applyFilters);
  }
  applyFilters();
}

function initContactForm() {
  const form = document.getElementById('contact-form');
  if (!form) return;
  const statusEl = document.getElementById('contact-status');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    statusEl.textContent = 'Sending...';
    const formData = new FormData(form);
    const payload = Object.fromEntries(formData.entries());

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to send message');
      statusEl.style.color = '#16a34a';
      statusEl.textContent = data.message || 'Message sent!';
      form.reset();
    } catch (e) {
      statusEl.style.color = '#b91c1c';
      statusEl.textContent = e.message || 'Something went wrong.';
    }
  });
}

async function initAdmin() {
  const form = document.getElementById('admin-add-listing');
  const statusEl = document.getElementById('admin-status');
  const listContainer = document.getElementById('admin-listings');

  if (!form || !listContainer) return;

  async function loadAdminListings() {
    listContainer.innerHTML = '';
    const listings = await fetchListings();
    listings.slice().reverse().forEach(l => {
      const row = document.createElement('div');
      row.style.fontSize = '0.85rem';
      row.style.padding = '0.25rem 0';
      row.style.borderBottom = '1px solid #e5e7eb';
      row.innerHTML = `<strong>${l.title}</strong> — ${l.location} — <span>${l.price}</span>`;
      listContainer.appendChild(row);
    });
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    statusEl.textContent = 'Saving...';
    const formData = new FormData(form);
    const payload = Object.fromEntries(formData.entries());

    try {
      const res = await fetch('/api/admin/listings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save listing');
      statusEl.style.color = '#16a34a';
      statusEl.textContent = 'Listing added successfully.';
      form.reset();
      await loadAdminListings();
    } catch (e) {
      statusEl.style.color = '#b91c1c';
      statusEl.textContent = e.message || 'Something went wrong.';
    }
  });

  await loadAdminListings();
}

// Initialise everything
document.addEventListener('DOMContentLoaded', () => {
  renderHomepageListings();
  renderAllListings();
  initContactForm();
  initAdmin();
});